import { useState, useEffect } from 'react';
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

interface Interaction {
  type: 'view' | 'like' | 'save';
  itemId: string;
  category: string;
  timestamp: number;
}

export const useRecommendations = (interactions: Interaction[]) => {
  const [recommendations, setRecommendations] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (interactions.length === 0) return;

    const generateRecommendations = async () => {
      setLoading(true);
      setError(null);
      try {
        const response = await ai.models.generateContent({
          model: "gemini-3-flash-preview",
          contents: `Based on these user interactions: ${JSON.stringify(interactions)}, 
          suggest 3 tailored classifieds categories, local services, or marketplace features 
          the user might be interested in. 
          The user is browsing a premium classifieds platform called Lokal Personal Service.
          Each suggestion must have a 'title', 'description', and a 'category' tag.
          Return as JSON.`,
          config: {
            responseMimeType: "application/json",
            responseSchema: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  title: { type: Type.STRING },
                  description: { type: Type.STRING },
                  category: { type: Type.STRING }
                },
                required: ["title", "description", "category"]
              }
            }
          }
        });

        const data = JSON.parse(response.text || "[]");
        setRecommendations(data);
      } catch (err: any) {
        console.error("Failed to generate recommendations:", err);
        setError(err.message || "Failed to fetch suggestions");
      } finally {
        setLoading(false);
      }
    };

    const timer = setTimeout(generateRecommendations, 2000); // Debounce
    return () => clearTimeout(timer);
  }, [interactions]);

  return { recommendations, loading, error };
};
