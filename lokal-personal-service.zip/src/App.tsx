/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, Component, ErrorInfo, ReactNode } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  ShieldCheck, 
  Zap, 
  Search, 
  Bell, 
  ArrowUpRight,
  Plus,
  ShoppingBag,
  Briefcase,
  Home,
  Users as UsersIcon,
  Heart,
  Car,
  ChevronRight,
  LogOut,
  User as UserIcon,
  Sparkles,
  History,
  Bookmark,
  MapPin,
  Camera,
  Tag,
  TrendingUp,
  Wrench,
  Scissors,
  Stethoscope,
  CreditCard,
  Wallet,
  Shield,
  CheckCircle2,
  Crown,
  Star,
  ZapIcon,
  Globe,
  BarChart3,
  LineChart,
  Activity,
  ArrowUp,
  ArrowDown
} from "lucide-react";
import { useAuth } from "./context/AuthContext";
import { useRecommendations } from "./hooks/useRecommendations";
import { isFirebaseConfigured } from "./lib/firebase";

// Locanto inspired categories
const categories = [
  { id: 'sale', title: 'Buy & Sell', icon: <ShoppingBag size={24} />, color: 'bg-emerald-500/10 text-emerald-500', count: '12k+' },
  { id: 'jobs', title: 'Jobs', icon: <Briefcase size={24} />, color: 'bg-blue-500/10 text-blue-500', count: '5k+' },
  { id: 'housing', title: 'Housing', icon: <Home size={24} />, color: 'bg-purple-500/10 text-purple-500', count: '8k+' },
  { id: 'community', title: 'Community', icon: <UsersIcon size={24} />, color: 'bg-amber-500/10 text-amber-500', count: '3k+' },
  { id: 'personals', title: 'Personals', icon: <Heart size={24} />, color: 'bg-red-500/10 text-red-500', count: '2k+' },
  { id: 'vehicles', title: 'Vehicles', icon: <Car size={24} />, color: 'bg-cyan-500/10 text-cyan-500', count: '1k+' },
  { id: 'services', title: 'Services', icon: <Wrench size={24} />, color: 'bg-orange-500/10 text-orange-500', count: '9k+' },
];

class ErrorBoundary extends Component<{ children: ReactNode }, { hasError: boolean, error: Error | null }> {
  constructor(props: { children: ReactNode }) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error) {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error("Uncaught error:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-brand-bg flex items-center justify-center p-8">
          <div className="max-w-md w-full p-8 rounded-[2.5rem] bg-brand-card border border-red-500/20 text-center space-y-6">
            <div className="w-16 h-16 bg-red-500/10 rounded-2xl flex items-center justify-center text-red-500 mx-auto">
              <ShieldCheck size={32} />
            </div>
            <h2 className="text-2xl font-black uppercase tracking-tighter">System Error</h2>
            <p className="text-brand-muted text-sm font-bold leading-relaxed">
              The application encountered a runtime error. This may be due to missing configuration or a layout conflict.
            </p>
            <div className="p-4 bg-black/40 rounded-xl text-left overflow-hidden border border-white/5">
              <code className="text-[10px] text-red-400 font-mono break-all line-clamp-3">
                {this.state.error?.message}
              </code>
            </div>
            <button 
              onClick={() => window.location.reload()}
              className="w-full py-4 bg-white text-black rounded-2xl font-black text-xs uppercase tracking-widest hover:scale-105 active:scale-95 transition-all"
            >
              Restart Dashboard
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

export default function App() {
  const { user, loginWithGoogle, logout, loading: authLoading } = useAuth();
  const [interactions, setInteractions] = useState<{type: 'view' | 'like' | 'save', itemId: string, category: string, timestamp: number}[]>([]);
  const { recommendations, loading: recsLoading, error: recsError } = useRecommendations(interactions);
  const [searchQuery, setSearchQuery] = useState("");
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [paymentMethods, setPaymentMethods] = useState([
    { id: '1', last4: '4242', brand: 'Visa', expiry: '12/26', isDefault: true },
    { id: '2', last4: '8888', brand: 'Mastercard', expiry: '09/25', isDefault: false }
  ]);
  const [seoData, setSeoData] = useState([
    { keyword: 'cheap laptops mumbai', rank: 3, change: 2 },
    { keyword: 'plumber near me', rank: 1, change: 0 },
    { keyword: 'second hand cars', rank: 12, change: -4 },
  ]);

  const trackInteraction = (type: 'view' | 'like' | 'save', category: string) => {
    const newInteraction = { type, itemId: Math.random().toString(), category, timestamp: Date.now() };
    setInteractions(prev => [newInteraction, ...prev].slice(0, 10));
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.1 } }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1 }
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-brand-bg flex items-center justify-center">
        <div className="w-10 h-10 border-4 border-brand-accent border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <ErrorBoundary>
      <div className="min-h-screen flex flex-col selection:bg-brand-accent selection:text-black">
      {/* Payment Modal */}
      <AnimatePresence>
        {showPaymentModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowPaymentModal(false)}
              className="absolute inset-0 bg-black/80 backdrop-blur-xl"
            />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="relative w-full max-w-md bg-brand-card border border-brand-border rounded-[2.5rem] p-8 shadow-2xl overflow-hidden"
            >
              <div className="flex items-center gap-4 mb-8">
                <div className="w-12 h-12 bg-brand-accent rounded-2xl flex items-center justify-center text-black">
                  <CreditCard size={24} />
                </div>
                <div>
                  <h3 className="text-xl font-black uppercase tracking-tighter">Add Card</h3>
                  <p className="text-xs text-brand-muted font-bold uppercase tracking-widest">Cloud-Linked SSL Secure</p>
                </div>
              </div>

              <div className="space-y-6">
                <div className="space-y-2">
                   <label className="text-[9px] font-black uppercase tracking-[0.2em] text-zinc-500 ml-2">Cardholder Name</label>
                   <input type="text" className="w-full bg-black/40 border border-white/5 rounded-2xl p-4 text-sm focus:outline-none focus:border-brand-accent/50 placeholder:text-zinc-800" placeholder="J. DOE" />
                </div>
                <div className="space-y-2">
                   <label className="text-[9px] font-black uppercase tracking-[0.2em] text-zinc-500 ml-2">Card Number</label>
                   <input type="text" className="w-full bg-black/40 border border-white/5 rounded-2xl p-4 text-sm focus:outline-none focus:border-brand-accent/50 placeholder:text-zinc-800" placeholder="•••• •••• •••• ••••" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                     <label className="text-[9px] font-black uppercase tracking-[0.2em] text-zinc-500 ml-2">Expiry</label>
                     <input type="text" className="w-full bg-black/40 border border-white/5 rounded-2xl p-4 text-sm focus:outline-none focus:border-brand-accent/50 placeholder:text-zinc-800" placeholder="MM/YY" />
                  </div>
                  <div className="space-y-2">
                     <label className="text-[9px] font-black uppercase tracking-[0.2em] text-zinc-500 ml-2">CVC</label>
                     <input type="text" className="w-full bg-black/40 border border-white/5 rounded-2xl p-4 text-sm focus:outline-none focus:border-brand-accent/50 placeholder:text-zinc-800" placeholder="•••" />
                  </div>
                </div>
              </div>

              <div className="mt-10 flex flex-col gap-4">
                <button 
                  onClick={() => setShowPaymentModal(false)}
                  className="w-full py-4 bg-brand-accent text-black rounded-2xl font-black text-xs uppercase tracking-widest shadow-[0_10px_20px_rgba(45,212,191,0.2)] hover:scale-105 active:scale-95 transition-all"
                >
                  Confirm & Link Card
                </button>
                <div className="flex items-center justify-center gap-2 opacity-30">
                  <Shield size={12} />
                  <span className="text-[8px] font-black uppercase tracking-widest">Encrypted by Nexus Security</span>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Navbar */}
      <nav className="h-16 px-6 md:px-8 flex items-center justify-between border-b border-brand-border/50 sticky top-0 bg-brand-bg/80 backdrop-blur-md z-50">
        {!isFirebaseConfigured && (
          <div className="absolute -bottom-10 left-0 right-0 h-10 bg-red-900/40 backdrop-blur-md border-b border-red-500/20 flex items-center justify-center px-4 overflow-hidden">
            <div className="flex items-center gap-2 text-red-200 text-[10px] font-black uppercase tracking-widest text-center">
              <ShieldCheck size={12} className="text-red-400" />
              Developer: Add Firebase Secrets to enable Authentication & Recommendations
            </div>
          </div>
        )}
        <div className="flex items-center gap-3">
          <div className="w-7 h-7 bg-brand-accent rounded-md flex items-center justify-center shadow-[0_0_20px_rgba(45,212,191,0.3)]">
            <Sparkles size={16} className="text-black" />
          </div>
          <span className="font-black text-xl tracking-tight uppercase">LOKAL PERSONAL SERVICE</span>
        </div>
        
        <div className="hidden lg:flex items-center flex-1 max-w-2xl mx-12 relative group">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-brand-muted group-focus-within:text-brand-accent transition-colors" size={18} />
          <input 
            type="text" 
            placeholder="Search millions of ads in India..." 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-brand-card border border-brand-border rounded-xl py-2.5 pl-12 pr-4 text-sm focus:outline-none focus:border-brand-accent/50 transition-all placeholder:text-zinc-600 focus:shadow-[0_0_20px_rgba(45,212,191,0.1)]"
          />
        </div>

        <div className="flex items-center gap-4">
          <button className="hidden sm:flex items-center gap-2 bg-brand-accent text-brand-bg px-5 py-2.5 rounded-xl font-black text-xs hover:scale-105 active:scale-95 transition-all shadow-[0_4px_15px_rgba(45,212,191,0.3)]">
            <Plus size={16} />
            POST FREE AD
          </button>
          
          <div className="h-8 w-[1px] bg-brand-border/50 mx-2 hidden sm:block" />

          {user ? (
            <div className="flex items-center gap-4">
              <div className="flex flex-col items-end hidden sm:flex">
                <span className="text-[11px] font-black truncate max-w-[120px] uppercase">{user.displayName}</span>
                <span className="text-[9px] text-brand-accent font-bold tracking-widest uppercase">Verified User</span>
              </div>
              <div className="group relative">
                <img 
                  src={user.photoURL || ""} 
                  alt="Avatar" 
                  className="w-10 h-10 rounded-xl border-2 border-brand-border cursor-pointer hover:border-brand-accent transition-colors p-0.5"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute top-full right-0 mt-3 w-52 bg-brand-card border border-brand-border rounded-2xl p-2 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all shadow-2xl z-50">
                  <div className="p-3 border-b border-brand-border/50 mb-1">
                    <p className="text-[10px] text-brand-muted font-bold uppercase mb-1">Signed in as</p>
                    <p className="text-xs font-bold truncate">{user.email}</p>
                  </div>
                  <button onClick={logout} className="w-full flex items-center gap-2 p-3 text-red-400 hover:bg-red-400/10 rounded-xl transition-colors text-sm font-bold">
                    <LogOut size={16} />
                    Log Out
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <button 
              onClick={loginWithGoogle}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-white/5 border border-brand-border hover:bg-white/10 transition-colors text-xs font-black uppercase"
            >
              <UserIcon size={18} />
              Login
            </button>
          )}
        </div>
      </nav>

      <main className="flex-1 p-6 md:p-10 max-w-7xl mx-auto w-full">
        <motion.div 
          className="bento-grid gap-6 md:gap-8"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          {/* HERO CARD (2x2) */}
          <motion.div variants={itemVariants} className="bento-card bento-card-hero md:col-span-2 md:row-span-2 group overflow-hidden border-brand-accent/30">
            <div className="relative z-10 h-full flex flex-col justify-between">
              <div className="space-y-6">
                <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-brand-accent/10 border border-brand-accent/20 text-brand-accent text-[9px] uppercase font-black tracking-[0.2em]">
                  <MapPin size={12} /> India • Nationwide
                </div>
                <h1 className="text-5xl md:text-7xl lg:text-8xl font-black tracking-tighter leading-none">
                  Sell it <br />
                  <span className="text-brand-accent italic font-serif">Instantly.</span> <br />
                  Find it <br />
                  <span className="text-white/30 uppercase tracking-tighter">Locally.</span>
                </h1>
                <p className="text-brand-muted text-lg max-w-sm font-semibold leading-relaxed">
                  Join millions of shoppers discovering unique deals from their neighbors every single day.
                </p>
              </div>
              
              <div className="mt-8 flex items-center gap-6">
                 <button className="flex items-center gap-2 bg-white text-black px-6 py-3 rounded-2xl font-black text-xs uppercase tracking-widest hover:scale-105 active:scale-95 transition-all">
                   Explore All Ads <ArrowUpRight size={16} />
                 </button>
                 <div className="flex -space-x-2">
                   {[1,2,3].map(i => (
                     <img key={i} src={`https://picsum.photos/seed/face${i}/100/100`} className="w-8 h-8 rounded-full border-2 border-brand-card" referrerPolicy="no-referrer" />
                   ))}
                 </div>
              </div>
            </div>
            {/* Visual background elements */}
            <div className="absolute top-1/2 right-0 -translate-y-1/2 translate-x-1/2 w-96 h-96 bg-brand-accent/10 blur-[100px] rounded-full" />
          </motion.div>

          {/* PERSONALIZED AI FEED (1x2) */}
          <motion.div variants={itemVariants} className="bento-card md:row-span-2 bg-zinc-950 border-white/5">
            <div className="h-full flex flex-col">
              <div className="flex items-center justify-between mb-10">
                <div className="flex items-center gap-2">
                  <Sparkles size={18} className="text-brand-accent" />
                  <span className="text-[10px] uppercase font-black tracking-widest text-brand-muted">AI Recommendations</span>
                </div>
                {recsLoading && <div className="w-1.5 h-1.5 bg-brand-accent rounded-full animate-ping" />}
              </div>

              <div className="flex-1 space-y-6">
                <div className="space-y-4">
                  {recsLoading ? (
                    Array.from({length: 3}).map((_, i) => (
                      <div key={i} className="h-20 bg-white/5 rounded-2xl animate-pulse" />
                    ))
                  ) : recsError ? (
                    <div className="p-4 rounded-2xl bg-red-500/10 border border-red-500/20 text-red-500 text-[11px] font-bold">
                      <div className="flex items-center gap-2 mb-1 uppercase tracking-widest text-[9px]">
                        <ShieldCheck size={12} /> Model Error
                      </div>
                      {recsError}
                    </div>
                  ) : recommendations.length > 0 ? (
                    recommendations.map((rec, i) => (
                      <motion.div 
                        key={i} 
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className="p-4 rounded-2xl bg-brand-accent/5 border border-brand-accent/10 hover:border-brand-accent hover:bg-brand-accent/10 transition-all cursor-pointer group"
                      >
                        <div className="flex items-center justify-between mb-2">
                           <span className="text-[10px] font-black text-brand-accent uppercase tracking-tighter">{rec.category}</span>
                           <TrendingUp size={14} className="text-brand-accent opacity-0 group-hover:opacity-100 transition-opacity" />
                        </div>
                        <h4 className="text-sm font-bold mb-1 leading-tight">{rec.title}</h4>
                        <p className="text-[11px] text-brand-muted leading-relaxed line-clamp-2">{rec.description}</p>
                      </motion.div>
                    ))
                  ) : (
                    <div className="h-full flex flex-col items-center justify-center text-center p-6 border-2 border-dashed border-white/5 rounded-3xl opacity-20">
                      <Camera size={32} className="mb-4" />
                      <p className="text-xs font-bold uppercase tracking-widest leading-loose">
                        {user ? "View ads to reveal tailored deals" : "Sign in for AI recommendations"}
                      </p>
                    </div>
                  )}
                </div>

                {interactions.length > 0 && (
                  <div className="pt-4 border-t border-white/5">
                    <div className="text-[9px] uppercase font-black tracking-[0.2em] text-zinc-600 mb-4 flex items-center gap-2">
                      <History size={12} /> Recent Clicks
                    </div>
                    <div className="flex flex-wrap gap-2">
                       {Array.from(new Set(interactions.map(i => i.category))).map((cat, i) => (
                         <span key={i} className="px-2.5 py-1 rounded-lg bg-zinc-900 border border-white/5 text-[9px] font-bold uppercase">{cat}</span>
                       ))}
                    </div>
                  </div>
                )}
              </div>

              <button className="mt-8 w-full p-4 rounded-2xl bg-brand-card border border-brand-border text-brand-text font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-3 hover:bg-brand-accent hover:text-black hover:border-brand-accent transition-all group">
                <Bookmark size={14} /> 
                Your Saved Ads
                <ChevronRight size={14} className="group-hover:translate-x-1 transition-transform" />
              </button>
            </div>
          </motion.div>

          {/* CATEGORY TILES */}
          <div className="md:col-span-1 grid grid-cols-2 gap-6">
            {categories.slice(0, 4).map((cat) => (
              <motion.div 
                key={cat.id}
                variants={itemVariants}
                whileHover={{ y: -5, shadow: "0 20px 40px rgba(0,0,0,0.4)" }}
                onClick={() => trackInteraction('view', cat.title)}
                className="bento-card p-6 items-center justify-center text-center cursor-pointer group bg-zinc-950/50"
              >
                <div className={`w-14 h-14 rounded-3xl flex items-center justify-center mb-4 transition-all group-hover:scale-110 ${cat.color} group-hover:bg-brand-accent group-hover:text-black shadow-xl`}>
                  {cat.icon}
                </div>
                <div className="text-[11px] font-black uppercase tracking-widest mb-1 text-brand-text">{cat.title}</div>
                <div className="text-[9px] text-brand-muted font-bold opacity-60">{cat.count} listings</div>
              </motion.div>
            ))}
          </div>

          {/* TRENDING BAR (2x1) */}
          <motion.div 
            variants={itemVariants} 
            className="bento-card md:col-span-2 !flex-row items-center border-brand-accent/20 bg-brand-accent/5 group cursor-pointer"
          >
            <div className="flex-1">
              <div className="flex items-center gap-2 text-[10px] uppercase font-black text-brand-accent mb-2">
                <Tag size={14} className="fill-brand-accent/20" />
                Popular Searches
              </div>
              <div className="text-2xl font-black tracking-tighter flex items-center gap-3 overflow-hidden">
                <span className="whitespace-nowrap transition-transform duration-[20s] linear animate-marquee">
                  Used Cars • Macbooks • Apartments • Part-time Jobs • Furniture • Gym Equipments • Used Cars • Macbooks • Apartments
                </span>
              </div>
            </div>
            <div className="pl-6">
               <div className="w-12 h-12 rounded-2xl bg-brand-accent flex items-center justify-center text-black group-hover:scale-110 transition-transform">
                 <ArrowUpRight size={24} />
               </div>
            </div>
          </motion.div>

          {/* FEATURED CATEGORY (1x1) */}
          <motion.div variants={itemVariants} className="bento-card md:row-span-1 group cursor-pointer overflow-hidden p-0 relative border-zinc-800">
            <img 
              src="https://picsum.photos/seed/realestate/600/600" 
              className="absolute inset-0 w-full h-full object-cover opacity-30 group-hover:scale-110 transition-transform duration-1000"
              alt="Real Estate"
              referrerPolicy="no-referrer"
            />
            <div className="relative p-8 h-full flex flex-col justify-end bg-gradient-to-t from-black via-black/40 to-transparent">
              <span className="text-[10px] font-black text-cyan-400 mb-2 uppercase tracking-[0.3em]">Hot Property</span>
              <h3 className="text-3xl font-black leading-[0.9] mb-4 uppercase tracking-tighter italic">Luxury <br />Lifestyles</h3>
              <div className="flex items-center gap-3 group/btn">
                <span className="text-[11px] font-black uppercase tracking-widest">Browse Housing</span>
                <div className="w-6 h-6 rounded-lg bg-cyan-400/20 flex items-center justify-center text-cyan-400 group-hover/btn:bg-cyan-400 group-hover/btn:text-black transition-all">
                   <ChevronRight size={14} />
                </div>
              </div>
            </div>
          </motion.div>

          {/* PERSONAL SERVICES CARD (1x1) */}
          <motion.div variants={itemVariants} className="bento-card bg-orange-500/5 border-orange-500/20 group hover:border-orange-500 transition-all cursor-pointer relative overflow-hidden">
            {/* Premium Glow Effect */}
            <div className="absolute -top-10 -right-10 w-32 h-32 bg-orange-500/10 blur-3xl group-hover:bg-orange-500/20 transition-all" />
            
            <div className="flex flex-col h-full relative z-10">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 rounded-2xl bg-orange-500 text-black shadow-[0_0_20px_rgba(249,115,22,0.4)]">
                  <Wrench size={20} />
                </div>
                <div className="flex items-center gap-2 px-2 py-1 rounded-lg bg-orange-500/10 border border-orange-500/20">
                  <Crown size={10} className="text-orange-500" />
                  <span className="text-[8px] font-black text-orange-500 uppercase tracking-widest">Premium</span>
                </div>
              </div>

              <h3 className="text-2xl font-black italic tracking-tighter mb-2 italic">Pro <br />Services</h3>
              <p className="text-[10px] text-brand-muted font-bold leading-relaxed mb-6 uppercase tracking-tighter">
                Access verified top-tier specialists. <br />Priority support & Instant booking.
              </p>
              
              <div className="space-y-3 mb-6">
                <div className="flex items-center gap-2 text-[9px] font-bold text-orange-200/60">
                  <Star size={10} className="text-orange-500" /> 
                  <span>Top 1% Rated Experts</span>
                </div>
                <div className="flex items-center gap-2 text-[9px] font-bold text-orange-200/60">
                  <ZapIcon size={10} className="text-orange-500" /> 
                  <span>30min Express Response</span>
                </div>
              </div>

              <div className="mt-auto flex flex-col gap-2">
                <button className="w-full py-3 rounded-xl bg-orange-500 text-black text-[9px] font-black uppercase tracking-widest hover:scale-105 transition-transform flex items-center justify-center gap-2">
                  Upgrade Service <Plus size={12} />
                </button>
                <div className="flex items-center justify-center gap-2">
                  <div className="flex -space-x-1">
                    <div className="w-5 h-5 rounded-full bg-orange-500/20 border border-orange-500/30 flex items-center justify-center"><Scissors size={8} className="text-orange-500" /></div>
                    <div className="w-5 h-5 rounded-full bg-blue-500/20 border border-blue-500/30 flex items-center justify-center"><Stethoscope size={8} className="text-blue-500" /></div>
                  </div>
                  <span className="text-[8px] font-black text-brand-muted uppercase">940+ Premium Experts</span>
                </div>
              </div>
            </div>
          </motion.div>

          {/* WALLET & PAYMENT CARD (1x1) */}
          <motion.div variants={itemVariants} className="bento-card border-brand-accent/20 bg-brand-accent/5 group hover:border-brand-accent transition-all cursor-pointer overflow-hidden">
            <div className="flex flex-col h-full relative z-10">
              <div className="flex items-center justify-between mb-6">
                <div className="p-3 rounded-2xl bg-white text-black shadow-xl">
                  <Wallet size={20} />
                </div>
                <div className="text-[10px] font-black uppercase tracking-widest text-brand-accent">Secure Wallet</div>
              </div>
              
              <div className="space-y-3 mb-6">
                {paymentMethods.map(card => (
                   <div key={card.id} className="flex items-center justify-between p-3 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 transition-colors">
                     <div className="flex items-center gap-3">
                        <CreditCard size={16} className="text-brand-muted" />
                        <div className="flex flex-col">
                           <span className="text-[10px] font-black">•••• {card.last4}</span>
                           <span className="text-[8px] uppercase font-bold text-brand-muted">{card.brand}</span>
                        </div>
                     </div>
                     {card.isDefault && <CheckCircle2 size={12} className="text-brand-accent" />}
                   </div>
                ))}
              </div>

              <button 
                onClick={() => setShowPaymentModal(true)}
                className="mt-auto w-full py-3 rounded-xl bg-white/5 border border-white/10 text-[9px] font-black uppercase tracking-widest hover:bg-brand-accent hover:text-black transition-all"
              >
                Add Payment Method
              </button>
            </div>
          </motion.div>

          {/* GOOGLE SEARCH RANKING CARD (1x1-Wide or 1x1) - NEW */}
          <motion.div variants={itemVariants} className="bento-card border-zinc-800 bg-zinc-950 group hover:border-blue-500/50 transition-all cursor-pointer">
            <div className="flex flex-col h-full">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                   <div className="p-2.5 rounded-xl bg-blue-500/20 text-blue-500">
                     <Globe size={18} />
                   </div>
                   <div className="flex flex-col">
                      <span className="text-[10px] font-black uppercase tracking-widest">Search Insights</span>
                      <span className="text-[8px] font-bold text-brand-muted uppercase tracking-tighter">Live Google Index</span>
                   </div>
                </div>
                <Activity size={14} className="text-blue-500 animate-pulse" />
              </div>

              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="p-3 rounded-2xl bg-white/5 border border-white/5">
                  <div className="text-[8px] uppercase font-black text-brand-muted mb-1">Avg. Position</div>
                  <div className="text-xl font-black italic tracking-tighter text-blue-400">#4.2</div>
                </div>
                <div className="p-3 rounded-2xl bg-white/5 border border-white/5">
                  <div className="text-[8px] uppercase font-black text-brand-muted mb-1">CTR</div>
                  <div className="text-xl font-black italic tracking-tighter text-emerald-400">8.5%</div>
                </div>
              </div>

              <div className="space-y-2 mt-auto">
                 {seoData.map((item, i) => (
                   <div key={i} className="flex items-center justify-between py-1.5 border-b border-white/5 last:border-0">
                     <span className="text-[10px] font-bold text-brand-muted truncate max-w-[100px]">{item.keyword}</span>
                     <div className="flex items-center gap-2">
                        <span className="text-[10px] font-black italic">#{item.rank}</span>
                        {item.change !== 0 && (
                          <span className={`text-[8px] font-black flex items-center ${item.change > 0 ? 'text-emerald-500' : 'text-red-500'}`}>
                             {item.change > 0 ? <ArrowUp size={8} /> : <ArrowDown size={8} />}
                             {Math.abs(item.change)}
                          </span>
                        )}
                     </div>
                   </div>
                 ))}
              </div>
            </div>
          </motion.div>

        </motion.div>
      </main>

      {/* Styled Footer */}
      <footer className="p-12 md:p-20 border-t border-brand-border/30 bg-black/80 backdrop-blur-xl mt-12">
        <div className="max-w-7xl mx-auto flex flex-col gap-20">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-12">
             <div className="space-y-6">
               <div className="flex items-center gap-3">
                 <div className="w-6 h-6 bg-brand-accent rounded-md" />
                 <span className="font-extrabold text-lg uppercase tracking-widest text-brand-text">LOKAL PERSONAL SERVICE</span>
               </div>
               <p className="text-[11px] text-brand-muted leading-relaxed font-bold uppercase tracking-tighter max-w-[200px]">
                 Transforming local classifieds with artificial intelligence and high-performance design.
               </p>
             </div>
             
             {['Platform', 'Community', 'Resources'].map((title, i) => (
               <div key={i} className="space-y-6">
                 <h4 className="text-[11px] font-black uppercase tracking-[0.2em] text-brand-text">{title}</h4>
                 <div className="flex flex-col gap-3 font-bold uppercase text-[10px] text-brand-muted">
                    <a href="#" className="hover:text-brand-accent transition-colors">Link One</a>
                    <a href="#" className="hover:text-brand-accent transition-colors">Link Two</a>
                    <a href="#" className="hover:text-brand-accent transition-colors">Link Three</a>
                 </div>
               </div>
             ))}
          </div>

          <div className="flex flex-col md:flex-row items-center justify-between gap-8 pt-12 border-t border-white/5">
            <p className="text-brand-muted text-[9px] font-black tracking-[0.3em] uppercase opacity-40">
              Lokal Personal Service • Designed for the modern local economy
            </p>
            <div className="flex gap-1">
               {Array.from({length: 8}).map((_, i) => (
                 <div key={i} className="w-4 h-4 rounded bg-zinc-900 border border-white/10" />
               ))}
            </div>
          </div>
        </div>
      </footer>
    </div>
    </ErrorBoundary>
  );
}
